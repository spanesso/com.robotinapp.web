<?php
 
$lang['login_form_email_user'] = "Correo Electrónico";
$lang['login_form_password_user'] = "Contraseña";
$lang['login_form_btn'] = "Ingresar";
$lang['login_form_forgot_password'] = "Olvido contraseña?";
$lang['login_form_remember_me'] = "Recordarme";

$lang['login_form_sucess_message_welcome'] = "Bienvenido a Def-Com";
$lang['login_form_danger_message_empty_fields'] = "Todos los campos son obligatorios.";
$lang['login_form_danger_message_email_format'] = "El correo ingresado no es válido.";
$lang['login_form_danger_message_conexion_error'] = "Hubo un error de conexión, intentalo de nuevo.";
 
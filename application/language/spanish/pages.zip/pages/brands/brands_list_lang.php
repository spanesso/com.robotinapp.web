<?php

// *************************************************************************************************************
// ******************************************************* MENU ************************************************
// *************************************************************************************************************


$lang['menu_top_user_register'] = "Inscríbete";
$lang['menu_top_user_login'] = "Iniciar Sesión";
$lang['menu_top_user_login_mail'] = "Correo Electrónico";
$lang['menu_top_user_login_pass'] = "Contraseña";
$lang['menu_top_user_community_register'] = "Contraseña";
 
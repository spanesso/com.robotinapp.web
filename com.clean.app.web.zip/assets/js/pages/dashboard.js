$( document ).ready(function() {
    
//    setTimeout(function(){ Materialize.toast('Welcome to Alpha!', 4000) }, 4000);
//    setTimeout(function(){ Materialize.toast('You have 4 new notifications', 4000) }, 11000);
//    
//    
 
   
    
  
});
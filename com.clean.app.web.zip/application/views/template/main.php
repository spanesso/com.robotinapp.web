<?php
echo $content_body
?>



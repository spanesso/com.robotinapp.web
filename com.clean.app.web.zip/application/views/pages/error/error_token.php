
<div class="be-wrapper be-error be-error-404">
    <div class="be-content">
        <div class="main-content container-fluid">
            <div class="error-container">
                <div class="error-number">404</div>
                <div class="error-description">Token Inválido</div>
                <div class="error-goback-text">El token de registro ya fue usado y ha sido invalidado,
                    por favor pongase en contácto con el soporte técnico de AFI</div>
                <div class="error-goback-button"><a href="<?php echo PROYECT_ROOT . "login" ?>" class="btn btn-xl btn-primary">ir la Login</a></div>
                <div class="footer">&copy; 2016 AFI</div>
            </div>
        </div>
    </div>
</div>
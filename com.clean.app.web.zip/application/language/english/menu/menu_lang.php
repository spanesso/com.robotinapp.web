<?php

// *************************************************************************************************************
// ******************************************************* MENU ************************************************
// *************************************************************************************************************


$lang['menu_top_user_register'] = "Inscríbete";
$lang['menu_top_user_login'] = "Iniciar Sesión";
$lang['menu_top_user_login_mail'] = "Correo Electrónico";
$lang['menu_top_user_login_pass'] = "Contraseña";
$lang['menu_top_user_community_register'] = "Contraseña";

$lang['menu_home'] = "Inicio";
$lang['menu_who_we_are'] = "Quiénes Somos";
$lang['menu_services'] = "Servicios";
$lang['menu_services_personal'] = "Personal";
$lang['menu_services_business'] = "Empresarial";
$lang['menu_services_lab'] = "Experience Lab";
$lang['menu_resources'] = "Recursos";
$lang['menu_community'] = "Comunidad";
$lang['menu_contact'] = "Contácto";
